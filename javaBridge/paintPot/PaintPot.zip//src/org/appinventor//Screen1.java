package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Canvas;
import com.google.appinventor.components.runtime.Camera;
public class Screen1 extends Form implements HandlesEventDispatching {
  private HorizontalArrangement HorizontalArrangement1;
  private Button RedButton;
  private Button BlueButton;
  private Button GreenButton;
  private Canvas DrawingCanvas;
  private HorizontalArrangement HorizontalArrangement2;
  private Button TakePictureButton;
  private Button WipeButton;
  private Button BigButton;
  private Button SmallButton;
  private Camera Camera1;
  private int dotSize;
  protected void $define() {
    this.AppName("PaintPot");
    this.Scrollable(true);
    this.Title("Paint Pot");
    HorizontalArrangement1 = new HorizontalArrangement(this);
    RedButton = new Button(HorizontalArrangement1);
    RedButton.BackgroundColor(0xFFFF0000);
    RedButton.Text("Red");
    BlueButton = new Button(HorizontalArrangement1);
    BlueButton.BackgroundColor(0xFF0000FF);
    BlueButton.Text("Blue");
    GreenButton = new Button(HorizontalArrangement1);
    GreenButton.BackgroundColor(0xFF00FF00);
    GreenButton.Text("Green");
    DrawingCanvas = new Canvas(this);
    DrawingCanvas.BackgroundImage("kitty.png");
    HorizontalArrangement2 = new HorizontalArrangement(this);
    TakePictureButton = new Button(HorizontalArrangement2);
    TakePictureButton.Text("Take Picture");
    WipeButton = new Button(HorizontalArrangement2);
    WipeButton.Text("Wipe");
    BigButton = new Button(HorizontalArrangement2);
    BigButton.Text("Big Dots");
    SmallButton = new Button(HorizontalArrangement2);
    SmallButton.Text("Small Dots");
    Camera1 = new Camera(this);
    dotSize = 2;
    EventDispatcher.registerEventForDelegation(this, "ClickEvent", "Click" );
    EventDispatcher.registerEventForDelegation(this, "AfterPictureEvent", "AfterPicture" );
    EventDispatcher.registerEventForDelegation(this, "DraggedEvent", "Dragged" );
    EventDispatcher.registerEventForDelegation(this, "TouchedEvent", "Touched" );
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    if( component.equals(TakePictureButton) && eventName.equals("Click") ){
      TakePictureButtonClick();
      return true;
    }
    if( component.equals(BigButton) && eventName.equals("Click") ){
      BigButtonClick();
      return true;
    }
    if( component.equals(WipeButton) && eventName.equals("Click") ){
      WipeButtonClick();
      return true;
    }
    if( component.equals(SmallButton) && eventName.equals("Click") ){
      SmallButtonClick();
      return true;
    }
    if( component.equals(Camera1) && eventName.equals("AfterPicture") ){
      Camera1AfterPicture((String)params[0]);
      return true;
    }
    if( component.equals(RedButton) && eventName.equals("Click") ){
      RedButtonClick();
      return true;
    }
    if( component.equals(BlueButton) && eventName.equals("Click") ){
      BlueButtonClick();
      return true;
    }
    if( component.equals(DrawingCanvas) && eventName.equals("Dragged") ){
      DrawingCanvasDragged(((Float)params[0]).intValue(), ((Float)params[1]).intValue(), ((Float)params[2]).intValue(), ((Float)params[3]).intValue(), ((Float)params[4]).intValue(), ((Float)params[5]).intValue(), ((Boolean)params[6]).booleanValue());
      return true;
    }
    if( component.equals(DrawingCanvas) && eventName.equals("Touched") ){
      DrawingCanvasTouched(((Float)params[0]).intValue(), ((Float)params[1]).intValue(), ((Boolean)params[2]).booleanValue());
      return true;
    }
    if( component.equals(GreenButton) && eventName.equals("Click") ){
      GreenButtonClick();
      return true;
    }
    return false;
  }
  public void TakePictureButtonClick(){
  }
  public void BigButtonClick(){
    dotSize = (Integer) 2;
  }
  public void WipeButtonClick(){
  }
  public void SmallButtonClick(){
    dotSize = (Integer) 8;
  }
  public void Camera1AfterPicture(String image){
    DrawingCanvas.BackgroundColor(image);
  }
  public void RedButtonClick(){
    DrawingCanvas.PaintColor(Integer.valueOf(COLOR_RED));
  }
  public void BlueButtonClick(){
    DrawingCanvas.PaintColor(Integer.valueOf(COLOR_BLUE));
  }
  public void DrawingCanvasDragged(int startX, int startY, int prevX, int prevY, int currentX, int currentY, boolean draggedAnySprite){
    DrawingCanvas.DrawLine(prevX, prevY, currentX, currentY);
  }
  public void DrawingCanvasTouched(int x, int y, boolean touchedAnySprite){
    DrawingCanvas.DrawCircle(x, y, Float.valueOf(dotSize), true);
  }
  public void GreenButtonClick(){
    DrawingCanvas.PaintColor(Integer.valueOf(COLOR_GREEN));
  }
}