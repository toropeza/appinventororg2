package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.TinyWebDB;
import java.util.ArrayList;
public class Screen1 extends Form implements HandlesEventDispatching {
  private Image Image1;
  private HorizontalArrangement HorizontalArrangement1;
  private TextBox AnswerText;
  private Button AnswerButton;
  private Label QuestionLabel;
  private Label RightWrongLabel;
  private Button NextButton;
  private TinyWebDB TinyWebDB1;
  private ArrayList<Object> QuestionList;
  private int currentQuestionIndex;
  private ArrayList<Object> PictureList;
  private ArrayList<Object> AnswerList;
  protected void $define() {
    this.AppName("PresidentsQuiz");
    this.Scrollable(true);
    this.Title("President's Quiz");
    Image1 = new Image(this);
    Image1.Height(200);
    Image1.Width(LENGTH_FILL_PARENT);
    Image1.Picture("roosChurch.gif");
    HorizontalArrangement1 = new HorizontalArrangement(this);
    AnswerText = new TextBox(HorizontalArrangement1);
    AnswerText.Hint("Enter an answer");
    AnswerButton = new Button(HorizontalArrangement1);
    AnswerButton.Text("Submit");
    QuestionLabel = new Label(this);
    QuestionLabel.HasMargins(false);
    QuestionLabel.Text("Question...");
    RightWrongLabel = new Label(this);
    RightWrongLabel.HasMargins(false);
    NextButton = new Button(this);
    NextButton.Text("Next");
    TinyWebDB1 = new TinyWebDB(this);
    QuestionList = new ArrayList<Object>();
    QuestionList.add("Which president implemented the 'New Deal' during the Great Depression?");
    QuestionList.add("Which president granted communist China formal recognition in 1979?");
    QuestionList.add("Which president resigned due to the Watergate scandal?");
    QuestionList.add("Which president was in office when two atom bombs were dropped on Japan?");
    currentQuestionIndex = 1;
    PictureList = new ArrayList<Object>();
    PictureList.add("roosChurch.gif");
    PictureList.add("carterChina.gif");
    PictureList.add("nixon.gif");
    PictureList.add("atomic.gif");
    AnswerList = new ArrayList<Object>();
    AnswerList.add("Roosevelt");
    AnswerList.add("Carter");
    AnswerList.add("Nixon");
    AnswerList.add("Truman");
    EventDispatcher.registerEventForDelegation(this, "InitializeEvent", "Initialize" );
    EventDispatcher.registerEventForDelegation(this, "ClickEvent", "Click" );
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    if( component.equals(this) && eventName.equals("Initialize") ){
      thisInitialize();
      return true;
    }
    if( component.equals(AnswerButton) && eventName.equals("Click") ){
      AnswerButtonClick();
      return true;
    }
    if( component.equals(NextButton) && eventName.equals("Click") ){
      NextButtonClick();
      return true;
    }
    return false;
  }
  public void thisInitialize(){
    QuestionLabel.Text(String.valueOf(QuestionList.get(1 - 1)));
  }
  public void AnswerButtonClick(){
    if(Integer.valueOf(AnswerText.Text())==Integer.valueOf(AnswerList.get(currentQuestionIndex - 1))){
      RightWrongLabel.Text("Correct!");
    }
    else {
      RightWrongLabel.Text("Incorrect!");
    }
  }
  public void NextButtonClick(){
    AnswerText.Text("");
    RightWrongLabel.Text("");
    currentQuestionIndex = (int) (currentQuestionIndex + 1);
    if(currentQuestionIndex>Integer.valueOf(QuestionList.size())){
      currentQuestionIndex = (int) 1;
    }
    QuestionLabel.Text(String.valueOf(QuestionList.get(currentQuestionIndex - 1)));
    Image1.Picture(String.valueOf(PictureList.get(currentQuestionIndex - 1)));
  }
}