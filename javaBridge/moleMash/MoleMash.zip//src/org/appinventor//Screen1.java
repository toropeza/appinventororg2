package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Canvas;
import com.google.appinventor.components.runtime.ImageSprite;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.Clock;
import com.google.appinventor.components.runtime.Sound;
import java.util.Random;
public class Screen1 extends Form implements HandlesEventDispatching {
  private Canvas Canvas1;
  private ImageSprite Mole;
  private Button ResetButton;
  private HorizontalArrangement HorizontalArrangement1;
  private Label HitsLabel;
  private Label HitsCountLabel;
  private HorizontalArrangement HorizontalArrangement2;
  private Label MissesLabel;
  private Label MissesCountLabel;
  private Clock Clock1;
  private Sound Sound1;
  private Random random;
  protected void $define() {
    this.AppName("MoleMash");
    this.Scrollable(true);
    this.Title("Mole Mash");
    Canvas1 = new Canvas(this);
    Canvas1.Height(300);
    Canvas1.Width(LENGTH_FILL_PARENT);
    Mole = new ImageSprite(Canvas1);
    Mole.Initialize();
    Mole.Picture("mole.png");
    Mole.X(103);
    Mole.Y(141);
    ResetButton = new Button(this);
    ResetButton.Text("Reset");
    HorizontalArrangement1 = new HorizontalArrangement(this);
    HitsLabel = new Label(HorizontalArrangement1);
    HitsLabel.HasMargins(false);
    HitsLabel.Text("Hits: ");
    HitsCountLabel = new Label(HorizontalArrangement1);
    HitsCountLabel.HasMargins(false);
    HitsCountLabel.Text("0");
    HorizontalArrangement2 = new HorizontalArrangement(this);
    MissesLabel = new Label(HorizontalArrangement2);
    MissesLabel.HasMargins(false);
    MissesLabel.Text("Misses: ");
    MissesCountLabel = new Label(HorizontalArrangement2);
    MissesCountLabel.HasMargins(false);
    MissesCountLabel.Text("0");
    Clock1 = new Clock(this);
    Sound1 = new Sound(this);
    random = new Random();
    EventDispatcher.registerEventForDelegation(this, "InitializeEvent", "Initialize" );
    EventDispatcher.registerEventForDelegation(this, "TimerEvent", "Timer" );
    EventDispatcher.registerEventForDelegation(this, "ClickEvent", "Click" );
    EventDispatcher.registerEventForDelegation(this, "TouchedEvent", "Touched" );
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    if( component.equals(this) && eventName.equals("Initialize") ){
      thisInitialize();
      return true;
    }
    if( component.equals(Clock1) && eventName.equals("Timer") ){
      Clock1Timer();
      return true;
    }
    if( component.equals(ResetButton) && eventName.equals("Click") ){
      ResetButtonClick();
      return true;
    }
    if( component.equals(Mole) && eventName.equals("Touched") ){
      MoleTouched();
      return true;
    }
    if( component.equals(Canvas1) && eventName.equals("Touched") ){
      Canvas1Touched(((Float)params[0]).intValue());
      return true;
    }
    return false;
  }
  public void thisInitialize(){
    MoveMole();
  }
  public void Clock1Timer(){
    MoveMole();
  }
  public void ResetButtonClick(){
    HitsCountLabel.Text(String.valueOf(0));
    MissesCountLabel.Text(String.valueOf(0));
  }
  public void MoleTouched(){
    Sound1.Vibrate(100);
  }
  public void Canvas1Touched(int x){
    if(touchedSprite){
      HitsCountLabel.Text(String.valueOf((Integer.valueOf(HitsCountLabel.Text()) + 1)));
    }
    else {
      MissesCountLabel.Text(String.valueOf((Integer.valueOf(MissesCountLabel.Text()) + 1)));
    }
  }
  public void MoveMole(){
    Mole.MoveTo((random.nextInt((Integer.valueOf(Canvas1.Width()) - Integer.valueOf(Mole.Width())) - 0 +  1 ) + 0), (random.nextInt((Integer.valueOf(Canvas1.Height()) - Integer.valueOf(Mole.Height())) - 0 +  1 ) + 0));
  }
}