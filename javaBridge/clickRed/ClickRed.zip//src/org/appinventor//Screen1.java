package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Button;
public class Screen1 extends Form implements HandlesEventDispatching {
  private Button Button1;
  protected void $define() {
    this.AppName("ClickRed");
    this.Title("Screen1");
    Button1 = new Button(this);
    Button1.BackgroundColor(0xFF00FF00);
    Button1.Text("Turn RED");
    EventDispatcher.registerEventForDelegation(this, "ClickEvent", "Click" );
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    if( component.equals(Button1) && eventName.equals("Click") ){
      Button1Click();
      return true;
    }
    return false;
  }
  public void Button1Click(){
    Button1.BackgroundColor(Integer.valueOf(COLOR_RED));
  }
}