package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Web;
public class Screen1 extends Form implements HandlesEventDispatching {
  private Label StockInfoLabel;
  private HorizontalArrangement HorizontalArrangement1;
  private TextBox SymbolTextBox;
  private Button UpdateButton;
  private Web Web1;
  protected void $define() {
    this.AlignHorizontal(3);
    this.AppName("StockMarket");
    this.BackgroundColor(0xFF888888);
    this.Scrollable(true);
    this.Title("Current Stock Price");
    StockInfoLabel = new Label(this);
    StockInfoLabel.FontSize(22);
    StockInfoLabel.HasMargins(false);
    StockInfoLabel.Text("looking up stock price...");
    HorizontalArrangement1 = new HorizontalArrangement(this);
    SymbolTextBox = new TextBox(HorizontalArrangement1);
    SymbolTextBox.Hint("please enter a stock symbol");
    SymbolTextBox.Text("GOOG");
    UpdateButton = new Button(HorizontalArrangement1);
    UpdateButton.Text("Update");
    Web1 = new Web(this);
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    return false;
  }
}